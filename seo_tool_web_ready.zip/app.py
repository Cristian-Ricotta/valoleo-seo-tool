from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

def crawl_seo_data(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (compatible; ValoleoBot/1.0)'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        return {
            'title': soup.title.string.strip() if soup.title else 'Kein Title gefunden',
            'meta_description': soup.find('meta', attrs={'name': 'description'}).get('content', '') if soup.find('meta', attrs={'name': 'description'}) else 'Keine Meta Description',
            'h1': [h.get_text(strip=True) for h in soup.find_all('h1')],
            'h2': [h.get_text(strip=True) for h in soup.find_all('h2')],
            'alt_tags': [img.get('alt', '') for img in soup.find_all('img')],
        }
    except Exception as e:
        return {'error': f'Fehler beim Crawlen: {str(e)}'}

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/crawl', methods=['POST'])
def crawl():
    url = request.form.get('url')
    if not url.startswith("http"):
        url = "http://" + url
    data = crawl_seo_data(url)
    return render_template('results.html', url=url, data=data)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=10000)
